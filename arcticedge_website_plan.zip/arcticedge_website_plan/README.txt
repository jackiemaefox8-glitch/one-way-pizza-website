ARCTICEDGE HEATING & COOLING — WEBSITE PLAN PACKAGE

This package contains ONLY website-related planning and Google Antigravity build instructions based on:
“ArcticEdge-Client-Brief(1).pdf” (fictional practice project).

It intentionally excludes the brief's separate brand identity deliverables, CGI image production package, full gallery production, and marketing/social deliverables except where website pages need images or assets.

START HERE
1. Read MASTER_PROMPT_ANTIGRAVITY.md.
2. Open your project folder in Google Antigravity.
3. Paste the master prompt into Antigravity.
4. Ask Antigravity to create/update the planning files first, then implement in small phases.
5. Keep all facts labelled fictional/demo until this practice project is deliberately published as a fictional portfolio demo.

PROJECT FACTS FROM THE BRIEF (ALL FICTIONAL)
Business: ArcticEdge Heating & Cooling
Tagline: “Texas heat meets its match.”
Address: 2410 Fannin Street, Suite 180, Houston, TX 77002
Phone: (713) 555-0182
Email: hello@arcticedgeair.com
Hours: Mon–Fri 7am–7pm, Sat 8am–5pm; 24/7 emergency line
Founded: 2014
License: TX HVAC License #TACLA-90210
Owner: Ray Callahan
Team: 11 certified technicians, 2 office staff
Service areas: Houston, Katy, Sugar Land, Pasadena, The Woodlands, Baytown, Pearland, Cypress
Reputation claims: 4.8 stars from 950+ reviews; 6,200+ homes served
Services and pricing are detailed in PRD.md and TRD.md.

IMPORTANT CONTENT SAFETY
The brief is a fictional practice scenario. Do not present it as a real company online without the user's explicit approval. Do not invent actual customer testimonials, reviewer names/suburbs, licence/insurance proof documents, guarantees, map coordinates, real booking availability, or integrations. For missing source data, use a clear internal content requirement and do not publish fake proof. The brief asks for at least 12 named reviews; the actual names/suburbs/review text are not provided, so they must be supplied or explicitly approved as fictional demo content before publishing.

FOLDER MAP
- MASTER_PROMPT_ANTIGRAVITY.md — copy/paste prompt for Google Antigravity
- PRD.md — product requirements and scope
- AGENTS.md — working rules for the AI coding agent
- DESIGN_SYSTEM.md — visual system and responsive/accessibility rules
- ARCHITECTURE.md — proposed application structure and boundaries
- TRD.md — technical requirements and acceptance criteria
- APP_FLOW.md — page and user flows
- IMPLEMENTATION_PLAN.md — phased implementation sequence
- TESTING.md — QA and release checklist
- WEBSITE_CONTENT_INVENTORY.md — every requested page and content requirements

No website source code is generated in this package. It is the plan and Antigravity instructions for building the website.
