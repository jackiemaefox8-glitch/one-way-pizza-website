# AGENTS.md — Rules for AI Website Work

## Priority
Follow the uploaded client brief first, then this plan. Do not silently replace requirements with personal preferences. If requirements conflict or required source content is missing, document the issue and ask before publishing.

## Work method
1. Inspect the existing repository and report its framework, current files, run scripts, and state before changing anything.
2. Plan before coding. Read PRD.md, DESIGN_SYSTEM.md, ARCHITECTURE.md, TRD.md, APP_FLOW.md, IMPLEMENTATION_PLAN.md, and TESTING.md.
3. Make small, reviewable changes by phase. After each phase, run relevant checks and report results.
4. Preserve existing working features unless a change is explicitly required.
5. Never claim a build, test, accessibility audit, performance score, form submission, or deployment succeeded unless you actually ran/verified it.

## Source-of-truth and honesty
- Treat all ArcticEdge business information in the supplied brief as fictional practice data.
- Do not invent real customer reviews, reviewer names, suburbs, insurance documents, guarantees, live availability, map locations, or third-party integrations.
- If the repository lacks approved assets, do not leave broken-image boxes or generic placeholders. Use project-approved generated assets or ask for assets; document what is still blocked.
- Never use lorem ipsum or “coming soon”.
- Keep content requirements marked internally as `[NEEDS CONTENT]` until resolved; do not publish those markers as customer-facing copy.
- Use the supplied phone `(713) 555-0182` and email `hello@arcticedgeair.com` consistently in the demo.
- Do not publish the site, connect production services, send emails/SMS, charge money, or run destructive database changes without explicit user approval.

## Design quality
- Keep the layout clean, premium, practical, and easy to scan.
- No purple/blue gradients; no handshake stock-photo clichés.
- Use no more than three colours in a single view.
- Avoid excessive animation, visual clutter, and multiple competing button styles.
- Use real image assets that match HVAC work; no text/logos baked into generated photos.
- Respect `prefers-reduced-motion`.
- Mobile-first; 320px minimum supported width; 44px minimum touch targets.
- Accessible semantic HTML, labels, keyboard focus states, sufficient contrast, and useful alt text.

## Engineering and security
- Validate all user inputs on the server as well as client-side.
- Protect forms against spam and abuse; use rate limiting and safe error messages.
- Never expose private keys, service-role keys, SMTP credentials, or other secrets in client bundles.
- If a database is used, enforce server-side authorization and database row-level security where supported.
- Avoid collecting unnecessary personal data. Provide privacy and retention information.
- Use secure headers and current maintained dependencies; audit licenses and vulnerabilities.
- Keep forms truthful: show “request received” rather than “booking confirmed” unless actual scheduling is integrated and confirms it.
- Do not create a fake map or a fake third-party review widget.

## Definition of done
A phase is complete only when its acceptance criteria are met, relevant tests are run, failures are fixed or clearly documented, and the next phase is not started with unresolved critical failures.
