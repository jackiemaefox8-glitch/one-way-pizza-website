# Website Content Inventory

## Global site content
- Business name, tagline, phone, email, address, hours.
- Persistent click-to-call action and 24/7 emergency CTA.
- Service navigation, footer links, privacy/terms links.
- Favicon and Open Graph share image.

## Home page
- Hero with supplied proof points: 4.8 stars from 950+ reviews, founded 2014, 6,200+ homes served (all fictional demo claims).
- Services grid.
- Three-step process.
- Approved testimonials.
- Eight service areas.
- Emergency CTA.
- FAQ teaser.
- Minimum 400 words.

## Services hub
- AC repair, installation/replacement, heating/furnace, Comfort Plan, duct cleaning/air quality, smart thermostats, commercial HVAC, emergency service.
- Price anchors only where supplied.

## Dedicated service pages (each 600+ words)
For each page: problem, solution, process, pricing anchor, 4–6 FAQs, call CTA.
1. AC Repair — $79 diagnostic visit, waived if repair is hired.
2. AC Installation — free in-home estimate; explain SEER in plain English.
3. Heating — heating/furnace repair and installation.
4. Maintenance Plan — ArcticEdge Comfort Plan details, $21/month.
5. Duct Cleaning & Air Quality — duct cleaning, purifiers, humidity control.
6. Commercial HVAC — rooftop units and maintenance contracts.

## Comfort Plan
- $21/month.
- Two tune-ups per year.
- Priority scheduling.
- 15% off repairs.
- Signup request form; do not imply payment enrollment unless billing is implemented and approved.

## About
- Company story, owner Ray Callahan, team count (11 technicians, 2 office staff), licence details and insurance proof area.
- Licence and insurance evidence are not included in the brief; do not fabricate documents or imply independent verification.

## Reviews
- Filterable testimonials.
- Minimum 12 names + suburbs + review text requested by brief.
- Actual 12 review records are missing from source. Obtain approved review source data or explicit permission to label content as fictional sample reviews for a portfolio demo.

## Service areas
- Houston
- Katy
- Sugar Land
- Pasadena
- The Woodlands
- Baytown
- Pearland
- Cypress
Each area needs distinct copy but no invented local customer stories or fake local proof.

## Booking
- Service selector.
- Preferred date.
- Preferred time window.
- Contact details.
- Short issue description.
- Validation, spam protection, loading, failure, success confirmation.
- A real booking calendar/provider is not specified. Without integration, present it as a booking request, not a confirmed appointment.

## Contact
- Phone and email.
- Business hours and emergency message.
- Contact form.
- Map embed only after a correct map source/location is confirmed.

## Blog — 3 launch articles
Suggested titles from brief or directly aligned with it:
1. “How Often Should Your AC Be Serviced in Houston Heat?”
2. “Repair or Replace Your AC? Questions to Ask Before You Decide”
3. “What a Smart Thermostat Can—and Cannot—Do for Your Home”
Write substantive, helpful copy. Do not invent technical guarantees or cite unsupported savings figures.

## Legal and error pages
- Privacy Policy.
- Terms.
- Custom 404.
Legal copy needs review for actual deployment and jurisdiction.
