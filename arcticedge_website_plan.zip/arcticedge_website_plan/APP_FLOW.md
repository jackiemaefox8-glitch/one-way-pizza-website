# App Flow and Site Map — ArcticEdge

## Global navigation
- Home
- Services (hub with six dedicated service pages and smart thermostat information)
- Comfort Plan
- Service Areas
- Reviews
- About
- Blog
- Contact
- Persistent phone CTA; emergency CTA accessible from every page
- Footer: contact details, hours, service areas, privacy, terms

## Routes
- `/` — Home
- `/services` — Services hub
- `/services/ac-repair`
- `/services/ac-installation`
- `/services/heating`
- `/services/maintenance-plan`
- `/services/duct-cleaning-air-quality`
- `/services/commercial-hvac`
- `/comfort-plan`
- `/about`
- `/reviews`
- `/service-areas`
- `/service-areas/houston`
- `/service-areas/katy`
- `/service-areas/sugar-land`
- `/service-areas/pasadena`
- `/service-areas/the-woodlands`
- `/service-areas/baytown`
- `/service-areas/pearland`
- `/service-areas/cypress`
- `/booking`
- `/contact`
- `/blog`
- `/blog/[article-slug]` for each of the three launch articles
- `/privacy`
- `/terms`
- `/404` or framework-native not-found route

## Main visitor flows

### Emergency AC repair
Home/service page → emergency banner or sticky phone CTA → click-to-call. Booking is secondary for urgent cases.

### Routine service
Home → Services → selected service → review price/process/FAQs → Request Booking → select service/time window → enter contact details → validate → submit → confirmation only after successful backend response.

### System replacement
Home → AC Installation → understand free estimate and SEER guidance → quote/contact form → success state.

### Comfort Plan
Home or Services → Comfort Plan → read inclusions and $21/month price → signup form → validated submission → request confirmation. Do not imply a recurring payment has been created unless billing is actually integrated and explicitly approved.

### Trust research
Home → About / Reviews / Service Areas → inspect approved information → call or contact.

### Blog discovery
Home/blog listing → practical article → contextual service CTA → service page/contact.

## Form states
- Idle: labels and short explanation.
- Invalid: field-level message and focus management.
- Submitting: disabled submit button and clear loading indicator.
- Failure: understandable message; preserve form input.
- Success: explain what was received and what happens next. Never claim a booking is confirmed unless a real scheduler confirms it.

## Emergency banner logic
The brief says after-hours visitors should see the 24/7 message first. The safest baseline is to show a compact 24/7 emergency call banner consistently. If implementing conditional visibility, use a tested Houston-local timezone rule, test daylight saving time, and ensure the emergency CTA is still available at all times.
