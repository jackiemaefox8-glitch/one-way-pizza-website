# Technical Requirements — ArcticEdge Website

## Functional requirements
- All routes listed in APP_FLOW.md exist, are linked appropriately, and return useful pages.
- Header and footer navigation work on desktop and mobile.
- Click-to-call uses `tel:+17135550182`; email uses `mailto:hello@arcticedgeair.com`.
- Emergency banner displays 24/7 emergency messaging; time-aware messaging must use a correct timezone and tested logic. If reliable timezone/time logic is not implemented, always display a clear 24/7 emergency CTA instead of incorrectly hiding it.
- Booking form: service selection, preferred time window, contact details, validation, spam protection, loading, error, and success states.
- Quote/contact forms behave similarly.
- Comfort Plan signup captures only necessary details and describes $21/month plan accurately.
- Reviews filters work with supplied/approved review records only.
- Service-area sections cover all eight named areas.
- FAQ accordions are keyboard accessible.
- Blog contains at least three substantive launch articles.
- Privacy and Terms routes are present; legal copy must be reviewed for the actual jurisdiction and real deployment before launch.
- Custom 404 route exists.

## Content requirements
- Home: at least 400 words.
- Each of six dedicated service pages: at least 600 words, with problem, solution, process, price anchor, 4–6 FAQs, and call CTA.
- Reviews: minimum 12 named testimonials with suburbs, but the brief does not include their source text/names/suburbs. Do not fabricate; ask for approved source data or explicit permission for clearly labelled fictional portfolio demo reviews.
- Service areas: Houston, Katy, Sugar Land, Pasadena, The Woodlands, Baytown, Pearland, Cypress; one distinct local section per area, without fake local proof.
- Blog: three launch articles, practical and plain-spoken.
- Keep all business contact details consistent.

## SEO
- Exactly one H1 per page.
- Unique title and meta description per route.
- Canonical URL per indexable page when the deployment domain is known.
- Open Graph title, description, and share image.
- `sitemap.xml`, `robots.txt`, favicon.
- Semantic headings and descriptive links.
- Structured data: LocalBusiness/HVACBusiness as appropriate, Service, and FAQPage only when the matching visible content is present. Avoid unsupported review aggregate markup and do not fabricate third-party rating data.
- No keyword stuffing or duplicate city-page content.

## Performance
- Target LCP <2.5s on a mid-range mobile device, measured.
- Mobile layout fully usable at 320px.
- Images compressed; aim for <=300KB per web image where visual quality allows.
- Use responsive image sizes, modern formats where supported, and lazy-load below-the-fold images.
- Reserve image dimensions/aspect ratios to reduce CLS.
- Avoid large client-side bundles and unnecessary animation libraries.
- No console errors or broken network requests in final QA.

## Accessibility
- Keyboard navigation and visible focus.
- Labels and error descriptions for all inputs.
- Minimum 44px tap targets.
- Contrast verified against WCAG AA targets.
- Respect reduced-motion preferences.
- Dialogs/accordions/filters announce state and support keyboard controls.

## Security and privacy
- Server-side input validation and safe output rendering.
- Spam protection and rate limiting.
- No secrets in frontend bundles or committed `.env` files.
- Do not collect or retain unnecessary personal data.
- Do not add payments, user accounts, or sensitive data collection; none are required by the brief.

## Acceptance gates
1. Build passes.
2. Routes and navigation checked.
3. Forms tested with valid and invalid input.
4. Mobile widths checked including 320px and 360px.
5. SEO metadata and structured data validated.
6. Accessibility and reduced motion reviewed.
7. Performance measured, not guessed.
8. Console/network checked for errors.
9. Missing content dependencies reported.
10. No public deployment without explicit approval.
