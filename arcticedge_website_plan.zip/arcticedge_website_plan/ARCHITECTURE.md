# Architecture — ArcticEdge Website

## Architecture principle
Inspect the existing project first and preserve its established stack if viable. Do not replace a working framework merely for preference. If this is a new project, choose a maintained, SEO-friendly framework already available in the environment; document the choice before implementation.

## Suggested structure (adapt to repository)
```text
/
├── public/
│   ├── images/
│   │   ├── hero/
│   │   ├── services/
│   │   ├── team/
│   │   └── gallery/
│   ├── favicon.svg
│   ├── robots.txt
│   └── og/
├── src/ (or framework equivalent)
│   ├── components/
│   │   ├── SiteHeader
│   │   ├── SiteFooter
│   │   ├── MobileCallBar
│   │   ├── EmergencyBanner
│   │   ├── ServiceCard
│   │   ├── ReviewCard
│   │   ├── FAQAccordion
│   │   └── ContactForm
│   ├── content/
│   │   ├── services
│   │   ├── service-areas
│   │   ├── blog
│   │   └── reviews
│   ├── pages/ or app/
│   ├── styles/
│   └── lib/
├── tests/
├── .env.example
├── README.md
└── planning/
```

## Main boundaries
- Presentation: page layouts and reusable components.
- Content: service descriptions, FAQs, blog articles, service area copy, and review records.
- Form handling: server-side validation and submission handler.
- SEO: metadata helpers, structured data, sitemap, robots, canonical URLs.
- Assets: local, optimised files with predictable names.
- Configuration: environment variables, with secrets only on the server.

## Data and forms
For the first implementation, booking may be a request form rather than a real-time appointment system. If no scheduling provider is configured, collect preferred day/time window and contact details, then show “request received” only after successful submission. Do not claim a slot is reserved. A backend or form provider must be explicitly configured before real submissions can be delivered.

Suggested booking fields: service, preferred date, time window, name, phone, email (if needed), service address or ZIP (if needed), short problem description, consent/privacy acknowledgement. Collect only necessary fields.

## Security
- Server-side schema validation.
- Rate limit submissions; use a honeypot or a vetted CAPTCHA option if appropriate.
- Escape/sanitise rendered user-provided content.
- Do not expose service-role keys or private API keys in browser code.
- Avoid storing payment data; this project does not require payments.
- Keep secrets in environment configuration and provide `.env.example` with names only.
- Do not invent or enable third-party integrations without approval.

## Routing
Implement all required routes from APP_FLOW.md. Prefer data-driven reusable service page templates while ensuring each page has unique, substantive copy and metadata.
