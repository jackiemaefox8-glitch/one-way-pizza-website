# Testing and Release Checklist — ArcticEdge Website

## Build and runtime
- [ ] Install dependencies using the repository's existing package manager.
- [ ] Run lint/typecheck/build scripts that actually exist.
- [ ] Start the site and inspect all required routes.
- [ ] No runtime exceptions or browser console errors.
- [ ] No broken image, font, script, or stylesheet requests.

## Responsive
- [ ] 320px wide.
- [ ] 360px wide.
- [ ] Common tablet width.
- [ ] Desktop width.
- [ ] Navigation usable with touch and keyboard.
- [ ] Sticky call CTA does not cover content or form submit buttons.
- [ ] No horizontal overflow.

## Navigation and content
- [ ] Every required page in APP_FLOW.md exists.
- [ ] Every internal navigation link works.
- [ ] One H1 per page.
- [ ] Home has at least 400 words.
- [ ] Six dedicated service pages each have at least 600 words.
- [ ] Each service page has problem, solution, process, pricing anchor, 4–6 FAQs, and CTA.
- [ ] Eight service areas represented.
- [ ] Three launch blog articles exist.
- [ ] Phone/email/hours are consistent.
- [ ] No lorem ipsum, “coming soon”, fake proof, or fabricated testimonials.
- [ ] All factual claims are traced to brief or approved content.

## Forms
- [ ] Required fields validate.
- [ ] Invalid email/phone and missing required fields show useful errors.
- [ ] Keyboard and screen-reader users can identify errors.
- [ ] Submit loading state works.
- [ ] Server-side validation runs.
- [ ] Spam protection/rate limiting configured.
- [ ] Successful test submission reaches the configured test destination.
- [ ] Failure state preserves user input.
- [ ] Confirmation does not falsely claim a booking is reserved.
- [ ] Privacy acknowledgement is present where appropriate.
- [ ] No real messages are sent during testing without approval.

## Emergency and phone
- [ ] `tel:+17135550182` works on supported devices.
- [ ] 24/7 emergency message is available at all times.
- [ ] Any after-hours logic uses Houston local time and is tested around daylight saving time.
- [ ] Emergency CTA is prominent without overwhelming the page.

## SEO
- [ ] Unique title and meta description per page.
- [ ] Canonical tags use the correct approved domain.
- [ ] Open Graph metadata and image exist.
- [ ] sitemap.xml works.
- [ ] robots.txt works.
- [ ] Favicon exists.
- [ ] LocalBusiness/Service/FAQ structured data validates and matches visible content.
- [ ] No unsupported aggregate review markup.
- [ ] Custom 404 page works.

## Accessibility
- [ ] Keyboard-only navigation.
- [ ] Visible focus indicators.
- [ ] Contrast checked against WCAG AA.
- [ ] 44px minimum tap targets.
- [ ] Images have appropriate alt text.
- [ ] Forms have associated labels.
- [ ] Accordions/filters expose correct accessible state.
- [ ] `prefers-reduced-motion` respected.

## Performance and security
- [ ] LCP measured on a mid-range mobile profile; target <2.5 seconds.
- [ ] Images compressed; aim <=300KB each where feasible.
- [ ] Below-fold images lazy-loaded.
- [ ] Image dimensions reserved to reduce CLS.
- [ ] No secrets in client bundles or committed environment files.
- [ ] Dependencies reviewed for maintenance, licences, and known vulnerabilities.
- [ ] User input validated server-side.
- [ ] No unnecessary personal data collected.

## Release gate
- [ ] All failures fixed or explicitly reported.
- [ ] Missing content dependencies reported.
- [ ] Test report states what was run and what was not run.
- [ ] User has explicitly approved any deployment or public publishing.
