# Design System — ArcticEdge Website

## Design direction
Create a calm, capable, local HVAC service brand: clear in emergencies, trustworthy during considered purchases, and visually consistent. Avoid nightclub gradients, overdecorated cards, fake luxury effects, and generic stock-photo clichés.

## Palette proposal
This is a design proposal for the fictional project, not a palette explicitly supplied by the client. Keep any one viewport to a maximum of three colours.

- Deep navy: `#12304A` — primary text, dark header/footer, high-trust anchors.
- Warm white: `#F7F6F2` — primary light background.
- Cool light grey: `#E8EDF0` — quiet section backgrounds, dividers, card surfaces.
- Safety orange: `#E56A2F` — primary CTA and emergency highlights.
- Charcoal: `#202A32` — body text on light backgrounds.

To obey the three-colour-per-view rule, use warm white + navy + orange on most conversion screens; use grey as a substitute background in a separate view, not an additional decorative accent. Verify WCAG AA contrast for all final text/button combinations before shipping.

## Typography
Maximum two font families:
- Headings: `Manrope` (600–800) — modern, sturdy, compact.
- Body: `Inter` (400–600) — highly readable.
Use system fallbacks. Verify licences and load fonts efficiently.

## Type scale
Desktop:
- H1: clamp(2.5rem, 5vw, 4.5rem), line-height 1.05
- H2: clamp(2rem, 3.5vw, 3rem), line-height 1.15
- H3: 1.25–1.5rem, line-height 1.25
- Body: 1rem–1.125rem, line-height 1.6
- Caption: 0.8125rem–0.875rem, line-height 1.45

Mobile:
- H1: clamp(2rem, 8vw, 3rem), line-height 1.08
- H2: clamp(1.625rem, 6vw, 2.25rem), line-height 1.18
- H3: 1.125–1.25rem
- Body: 1rem, line-height 1.55
- Caption: 0.8125rem

## Layout and components
- Content max width: approximately 72rem; readable article width 42–48rem.
- Use a consistent spacing scale based on 4px/8px increments.
- Header: wordmark/logo, Services, Comfort Plan, Service Areas, Reviews, About, Contact; clear phone CTA.
- Buttons: one primary filled style, one secondary outline/text style. Minimum 44px height.
- Cards: restrained radius (8–14px), subtle borders/shadows only where useful.
- Forms: visible labels, helpful inline errors, clear keyboard focus, loading/success/error states.
- Sticky mobile call CTA must not obscure page content or form actions.
- Emergency banner must be prominent without repeatedly interrupting users.

## Photography
- Photorealistic HVAC service imagery, bright natural daylight, consistent navy-uniform technician character where a technician appears.
- No readable text, fake logos, watermarks, handshake clichés, distorted hands, or inconsistent grading.
- Use local generated assets supplied to the project; no broken remote image dependencies.
- Use descriptive alt text for meaningful images; empty alt for purely decorative images.
- Use WebP/AVIF derivatives when supported, with appropriate responsive sizes and fallbacks.

## Motion
- Subtle entrance/hover transitions only; no long intro that delays access to emergency contact.
- Respect `prefers-reduced-motion`.
- Keep motion purposeful and avoid animating layout dimensions in ways that cause CLS.

## Accessibility
- Semantic landmarks and heading order.
- Keyboard-accessible navigation, forms, accordions, filters, dialogs, and controls.
- Visible focus indicators.
- WCAG AA text contrast target; do not rely on colour alone.
- Descriptive form errors announced accessibly.
