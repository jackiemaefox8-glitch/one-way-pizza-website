# Product Requirements Document — ArcticEdge Website

## 1. Project overview
Build a fast, trustworthy, mobile-first lead-generation website for the fictional practice business ArcticEdge Heating & Cooling in Houston, Texas. The primary conversion goals are phone calls and service/quote bookings. The user should be able to understand the service, find an appropriate next step, and contact the business quickly—even late at night during an AC emergency.

**Source:** ArcticEdge-Client-Brief(1).pdf, Sections 1 and 6. All business details are fictional and must be treated as demo data.

## 2. Goals
- Make click-to-call and emergency contact actions immediately visible on mobile.
- Explain all requested services in plain, neighbourly language.
- Support booking requests and quote requests with validation, spam protection, clear success and error states.
- Establish trust using only facts supplied by the brief and approved content.
- Make every required page responsive, accessible, searchable, and performant.
- Meet the brief's mobile target of 320px width and 44px minimum tap targets.
- Target LCP under 2.5 seconds on a mid-range mobile device; measure rather than claim.

## 3. Audience and core use cases
- A Houston-area homeowner whose AC has failed and needs urgent help.
- A homeowner considering system replacement or a maintenance plan.
- A household seeking indoor-air-quality, duct cleaning, thermostat, or heating services.
- A commercial property manager looking for rooftop HVAC service or maintenance.
- A visitor comparing service coverage, FAQs, process, and contact options.

## 4. Business facts provided by the fictional brief
- Name: ArcticEdge Heating & Cooling
- Tagline: “Texas heat meets its match.”
- Address: 2410 Fannin Street, Suite 180, Houston, TX 77002
- Phone: (713) 555-0182
- Email: hello@arcticedgeair.com
- Hours: Monday–Friday 7am–7pm; Saturday 8am–5pm; 24/7 emergency line
- Founded: 2014; owner: Ray Callahan
- Team: 11 certified technicians, 2 office staff
- Licence listed in brief: TX HVAC License #TACLA-90210
- Service areas: Houston, Katy, Sugar Land, Pasadena, The Woodlands, Baytown, Pearland, Cypress
- Reputation claims: 4.8 stars from 950+ reviews; 6,200+ homes served

These are fictional scenario details, not independently verified facts. The site must not be publicly launched as a real business without explicit review/approval.

## 5. Services and price anchors
- AC repair: $79 diagnostic visit, waived if customer hires the company for the repair.
- AC installation and full system replacement: free in-home estimate; explain SEER guidance in plain English.
- Heating and furnace repair and installation.
- ArcticEdge Comfort Plan: $21/month; two tune-ups per year, priority scheduling, 15% off repairs.
- Duct cleaning and indoor air quality: purifiers and humidity control.
- Smart thermostat supply, installation, and setup.
- Commercial HVAC: rooftop units and maintenance contracts.
- 24/7 emergency service; brief states real humans answer and no overtime fees.

Represent all listed services. The six dedicated service pages required are AC Repair, AC Installation, Heating, Maintenance Plan, Duct Cleaning & Air Quality, and Commercial HVAC. Smart thermostats and emergency service must still be represented on the Services hub and relevant pages/sections.

## 6. Required pages
1. Home — minimum 400 words; hero with proof, service grid, 3-step process, testimonials, service areas, emergency CTA, FAQ teaser.
2. Services hub.
3. AC Repair — minimum 600 words, 4–6 FAQs.
4. AC Installation — minimum 600 words, 4–6 FAQs.
5. Heating — minimum 600 words, 4–6 FAQs.
6. Maintenance Plan — minimum 600 words, 4–6 FAQs.
7. Duct Cleaning & Indoor Air Quality — minimum 600 words, 4–6 FAQs.
8. Commercial HVAC — minimum 600 words, 4–6 FAQs.
9. Comfort Plan — inclusions, $21/month, signup form.
10. About — story, Ray Callahan bio, team, licence/insurance proof area. Do not fabricate proof documents.
11. Reviews — filterable, minimum 12 testimonials with names and suburbs. Source material does not provide the 12 reviews; request approved review data and do not fabricate real-looking testimonials.
12. Service Areas — one section/page section per each of 8 cities with a locally relevant line of copy. Do not invent local customer proof.
13. Booking — choose service, time window, contact details, confirmation screen.
14. Contact — contact form, phone, hours, map embed, emergency banner.
15. Blog — at least 3 launch articles.
16. Privacy Policy.
17. Terms.
18. Custom 404 page.

The six dedicated service pages are in addition to the Services hub and the separate Comfort Plan page.

## 7. Conversion requirements
- Click-to-call links use `tel:+17135550182`.
- Mobile sticky call action visible without scrolling and not covering form controls.
- Emergency banner prioritises 24/7 contact information for after-hours visitors.
- Clear primary CTA such as “Call for Emergency Service” and secondary CTA “Request a Booking”.
- Booking and quote forms validate inputs, prevent spam, show loading/error/success states, and never imply a booking is confirmed until the backend actually confirms it.
- Every page has a sensible conversion path.

## 8. Content and trust rules
- Plain-spoken, Houston-friendly, confident, never pushy.
- Explain HVAC terms briefly.
- Avoid the phrases “cutting-edge solutions,” “we leverage synergies,” and “your comfort is our passion.”
- No lorem ipsum, fake testimonials, fake reviews, invented guarantees, unsupported licence/insurance claims, fake map pins, or fake availability.
- Use the supplied phone and email consistently.
- Do not use handshake clichés or generic AI-sounding copy.
- Missing review names/suburbs and proof documents are content dependencies, not permission to invent facts.

## 9. Out of scope for this website-only package
- Full brand identity deliverables (logo suite, business cards, uniform, van livery, brand guidelines).
- Producing the separate 12-image CGI library as deliverables.
- Producing the full 30+ image gallery as deliverables.
- Social media posts, A5 flyer, email header, and promotional video script.
These may be created in separate workstreams. The website can use approved generated images where necessary, but must not use placeholder boxes or broken images.

## 10. Success measures
- All required pages/routes exist and work.
- All forms have tested validation and confirmation behaviour.
- No broken links or console errors.
- Mobile usable at 320px; touch targets at least 44px.
- One H1 per page; unique title/meta description; OG metadata; canonical tags; sitemap.xml; robots.txt.
- Correct FAQ, LocalBusiness, and Service structured data where applicable.
- LCP target below 2.5s measured on a mid-range mobile device.
- Images compressed; below-the-fold images lazy-loaded; no API secrets exposed.
