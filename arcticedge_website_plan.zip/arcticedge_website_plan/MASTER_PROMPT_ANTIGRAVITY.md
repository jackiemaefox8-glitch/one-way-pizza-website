# Google Antigravity Master Prompt — ArcticEdge Website Only

Copy and paste this prompt into Google Antigravity after opening the project folder.

---

You are the lead product planner, UX/UI designer, full-stack engineer, accessibility reviewer, SEO specialist, and QA engineer for a WEBSITE-ONLY build based on the supplied fictional practice brief `ArcticEdge-Client-Brief(1).pdf`.

## First: obey the source and inspect the project
1. Inspect the current repository, framework, package manager, scripts, environment files, assets, and existing implementation before changing anything.
2. Read these project planning files first: `PRD.md`, `AGENTS.md`, `DESIGN_SYSTEM.md`, `ARCHITECTURE.md`, `TRD.md`, `APP_FLOW.md`, `IMPLEMENTATION_PLAN.md`, `TESTING.md`, and `WEBSITE_CONTENT_INVENTORY.md`.
3. If a required file is missing, create it using the supplied plan. Do not blindly overwrite working code or replace the framework without explaining why.
4. This is a fictional practice project. Treat every business detail and reputation claim as fictional demo data. Do not publish it as a real business or deploy publicly without explicit user approval.
5. Work in small phases. Do not attempt a giant unreviewed code dump. At the end of each phase, run checks, fix failures, and report what is complete and what remains.

## Scope: website deliverables only
Build the full responsive website and the website-supporting code/content/SEO/QA files. Do NOT build the separate logo suite, business card, invoice PDF, van livery, uniform mockup, full CGI image deliverable pack, 30-image gallery deliverable pack, Instagram posts, flyer, email header, or promo video script as part of this task. The website may use approved image assets already present in the project. If suitable images are missing, create a clearly documented asset request or use image-generation tools available in the environment to create photorealistic HVAC images. Never leave grey placeholder boxes, broken images, lorem ipsum, or “coming soon”.

## Business details from the fictional brief
- ArcticEdge Heating & Cooling
- Tagline: “Texas heat meets its match.”
- Address: 2410 Fannin Street, Suite 180, Houston, TX 77002
- Phone: (713) 555-0182
- Email: hello@arcticedgeair.com
- Hours: Mon–Fri 7am–7pm, Sat 8am–5pm; 24/7 emergency line
- Founded: 2014
- Owner: Ray Callahan
- Team: 11 certified technicians, 2 office staff
- Licence shown in the brief: TX HVAC License #TACLA-90210
- Service areas: Houston, Katy, Sugar Land, Pasadena, The Woodlands, Baytown, Pearland, Cypress
- Reputation claims in brief: 4.8 stars from 950+ reviews; 6,200+ homes served
- AC diagnostic visit: $79, waived if the customer hires ArcticEdge for the repair
- AC installation/replacement: free in-home estimate; provide plain-English SEER guidance
- ArcticEdge Comfort Plan: $21/month, two tune-ups per year, priority scheduling, 15% off repairs
- Other services: heating/furnace, duct cleaning and indoor air quality, purifiers, humidity control, smart thermostat supply/install/setup, commercial rooftop units and maintenance contracts
- Emergency service: 24/7; the brief says real humans answer and no overtime fees

Do not add facts, prices, guarantees, testimonials, customer names, suburbs, insurance proof, exact map pins, integrations, or real-time availability that are not supplied or approved. The brief does not contain the actual 12 named review records. Do not fabricate them. Build the review data model and review UI, then keep that content clearly gated or ask the user for approved review records. Do not publish internal `[NEEDS CONTENT]` labels to site visitors.

## Required pages and routes
- Home: minimum 400 words; hero with proof points, service grid, 3-step process, approved testimonials, service areas, emergency CTA, FAQ teaser.
- Services hub.
- Six dedicated service pages, each at least 600 words, with problem, solution, process, pricing anchor, 4–6 FAQs, and call CTA:
  1. AC Repair
  2. AC Installation
  3. Heating
  4. Maintenance Plan
  5. Duct Cleaning & Indoor Air Quality
  6. Commercial HVAC
- Comfort Plan page: inclusions, $21/month, signup/request form.
- About: story, Ray Callahan bio, team, licence and insurance proof area. Do not fake proof.
- Reviews: filterable, designed for at least 12 named testimonials with suburbs; use only approved records.
- Service Areas: eight areas—Houston, Katy, Sugar Land, Pasadena, The Woodlands, Baytown, Pearland, Cypress—with distinct copy but no invented local proof.
- Booking: service selector, preferred date/time window, contact details, validation, and truthful confirmation.
- Contact: form, phone, hours, map embed after correct map source is confirmed, emergency banner.
- Blog listing plus at least three launch articles.
- Privacy Policy and Terms.
- Custom 404 page.

## Visual direction
Use `DESIGN_SYSTEM.md`. Build a clean, premium, practical HVAC service website. Avoid purple/blue gradients, fake handshake imagery, noisy animations, too many cards, six different button styles, and AI-sounding filler. Proposed palette: deep navy `#12304A`, warm white `#F7F6F2`, cool grey `#E8EDF0`, safety orange `#E56A2F`, charcoal `#202A32`; keep each viewport to no more than three colours. Verify WCAG AA contrast. Use at most two font families (Manrope headings, Inter body, with fallbacks). Keep a clear phone CTA visible on mobile. The website should feel calm, reliable, local, and easy to use when someone has an AC emergency.

## Functional behaviour
- Click-to-call must use `tel:+17135550182`.
- Email link must use `mailto:hello@arcticedgeair.com`.
- Sticky mobile call CTA must be visible without scrolling and must not cover content.
- Keep a clear 24/7 emergency CTA available at all times. If implementing after-hours logic, use Houston local time and test daylight-saving transitions; do not hide emergency access.
- Booking and quote/contact forms need client and server validation, spam protection/rate limiting, loading/error/success states, and accessible errors.
- Unless a real scheduling integration is configured and verified, label the action as a booking request and never claim a time is reserved.
- Comfort Plan signup must not claim a paid subscription was created unless an approved billing integration exists.
- Use reusable components and data-driven templates, but give every service page unique substantive content and metadata.
- FAQ accordions and review filters must be keyboard accessible.

## Technical and SEO requirements
- Inspect and preserve a working existing stack; if new, select a maintained SEO-friendly stack and document the choice.
- One H1 per page; unique title and meta description; canonical URL once the approved domain is known; Open Graph metadata and share image.
- Include favicon, `sitemap.xml`, `robots.txt`, and suitable LocalBusiness/HVACBusiness, Service, and visible-content FAQ structured data.
- Do not add unsupported aggregate review schema or fabricated review counts.
- Optimise images, use responsive formats/sizes, lazy-load below-the-fold images, reserve dimensions, aim for <=300KB per web image when feasible.
- Target measured LCP under 2.5 seconds on a mid-range phone.
- Must work at 320px and 360px widths; touch targets at least 44px.
- Respect `prefers-reduced-motion`; semantic HTML, visible focus, associated labels, contrast, alt text.
- No exposed API keys, private keys, or service-role secrets. Validate input on the server. Do not add payment collection or unnecessary personal data.
- No broken links, missing favicon, missing 404, console errors, or fake social/review links.

## Work phases — stop and report at each gate
Phase 0: inspect repository, report current state and missing dependencies, confirm plan. Do not code yet.
Phase 1: build shared design system, header/footer, emergency banner, sticky mobile call CTA, responsive shell.
Phase 2: build Home, Services hub, and six service pages with verified brief-derived content.
Phase 3: build Comfort Plan, About, Service Areas, Reviews UI (without fabricated review content), Contact.
Phase 4: build Booking request flow and all form validation/states; do not connect real message delivery without approval.
Phase 5: build Blog with three useful articles, Privacy, Terms, custom 404, metadata/schema/sitemap/robots/favicon.
Phase 6: image optimisation, accessibility, SEO, performance, and security audit.
Phase 7: run full QA and produce a report listing passed, failed, and not-run checks, plus missing content dependencies.

## Final acceptance
Before claiming completion:
- Run the actual build and available lint/typecheck/test commands.
- Test all routes and links.
- Test valid and invalid form submissions.
- Test at 320px and 360px.
- Check browser console/network for errors.
- Check unique metadata, one H1 per page, sitemap, robots, favicon, 404, and structured data.
- Measure performance; do not guess or claim LCP success without a test result.
- Report missing review records, insurance/licence proof, map source, real form destination, domain, and any other blocked content.
- Do not deploy or publish publicly unless the user explicitly approves.

Begin with Phase 0 only. Inspect the repository and return a concise audit and proposed implementation sequence before modifying source files.
