# Implementation Plan — Website Only

## Phase 0 — Inspect and plan
Tasks:
- Inspect repository, framework, scripts, existing assets, and deployment setup.
- Confirm whether the project is new or an existing site.
- Create/update planning files and asset inventory.
- Identify missing approved assets/content: 12 named reviews and suburbs, licence/insurance evidence, real map location/URL, actual form destination, approved domain.
Done when:
- Current state and decisions are documented.
- No source code changed before the plan is reviewed.
Gate:
- Ask user before replacing the existing stack or adding paid services.

## Phase 1 — Foundation and design system
Tasks:
- Set up shared layout, typography, colour tokens, buttons, links, spacing, header/footer.
- Add mobile sticky call CTA and emergency banner.
- Add favicon and responsive image conventions.
Done when:
- Layout is responsive at 320px, 360px, tablet, and desktop.
- Keyboard focus and reduced motion work.
- No console errors.
Gate:
- Review the base Home layout before filling every route.

## Phase 2 — Core conversion pages
Tasks:
- Home (400+ words), Services hub, six dedicated service pages (600+ words each).
- Add pricing anchors, process, 4–6 FAQs per service page, phone CTA, quote/book links.
- Add Comfort Plan page and $21/month signup request form.
Done when:
- Unique copy and metadata exist for each route.
- All internal links work.
- No unsupported claims or duplicated filler.
Gate:
- Review all service and price statements against the brief.

## Phase 3 — Trust and location pages
Tasks:
- About, Reviews, Service Areas, Contact.
- Add eight city sections/pages.
- Implement review filtering using approved review data only.
- Add map only after correct location/map source is supplied.
Done when:
- No fake testimonials or fabricated local proof.
- Contact details consistent.
Gate:
- If 12 review records are still missing, keep Reviews unpublished/clearly gated for demo; do not fabricate.

## Phase 4 — Booking and forms
Tasks:
- Booking flow with service, preferred date/time window, contact details.
- Contact/quote and Comfort Plan request forms.
- Server-side validation, anti-spam, rate limits, accessible error/success states.
- Configure a real form destination only with user approval.
Done when:
- Invalid input rejected; valid request is delivered to the configured destination in a test.
- Confirmation is truthful; no fake reservation.
Gate:
- Do not send real messages or connect production secrets without approval.

## Phase 5 — Blog and legal pages
Tasks:
- Write three useful launch articles.
- Add Privacy and Terms pages and custom 404.
- Add metadata, sitemap, robots, canonicals, OG images, structured data.
Done when:
- All required routes render; metadata is unique; structured data matches visible content.
Gate:
- Legal pages flagged for review before real-world launch.

## Phase 6 — Assets, performance, SEO, accessibility
Tasks:
- Use approved/generated HVAC images, not generic placeholders.
- Optimise images; lazy-load below-fold images; reserve dimensions.
- Check contrast, headings, keyboard controls, tap targets, reduced motion.
- Run performance audit and improve bottlenecks.
Done when:
- Measured LCP target <2.5s or remaining gap documented.
- Images generally <=300KB where quality allows.
- No broken assets or links.
Gate:
- Do not claim performance success without a recorded test.

## Phase 7 — Full QA and handoff
Tasks:
- Run build, unit/component tests if configured, route smoke tests, form tests, accessibility checks, SEO checks, browser console/network checks.
- Test 320px and 360px mobile widths.
- Update README with run/build instructions and environment variables.
- Provide a report listing passed/failed/not-run checks and missing content.
Done when:
- No critical failures; all known limitations documented.
- User explicitly approves before deployment/public publishing.
